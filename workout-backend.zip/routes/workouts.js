const express = require('express')
const mongoose = require('mongoose')
const Workout = require('../models/Workout')

const router = express.Router()

// GET alle workouts
router.get('/', async (req, res) => {
  try {
    const workouts = await Workout.find().sort({ createdAt: -1 })
    res.status(200).json(workouts)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

// GET enkele workout
router.get('/:id', async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({ error: 'Geen geldige ID' })
  }

  const workout = await Workout.findById(id)

  if (!workout) {
    return res.status(404).json({ error: 'Workout niet gevonden' })
  }

  res.status(200).json(workout)
})

// POST nieuwe workout
router.post('/', async (req, res) => {
  const { title, reps, load } = req.body

  try {
    const workout = await Workout.create({ title, reps, load })
    res.status(200).json(workout)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

// DELETE workout
router.delete('/:id', async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({ error: 'Geen geldige ID' })
  }

  const workout = await Workout.findByIdAndDelete(id)

  if (!workout) {
    return res.status(404).json({ error: 'Workout niet gevonden' })
  }

  res.status(200).json(workout)
})

// PATCH workout
router.patch('/:id', async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({ error: 'Geen geldige ID' })
  }

  const workout = await Workout.findByIdAndUpdate(id, {
    ...req.body
  }, { new: true })

  if (!workout) {
    return res.status(404).json({ error: 'Workout niet gevonden' })
  }

  res.status(200).json(workout)
})

module.exports = router
