const express = require('express')
const mongoose = require('mongoose')
const dotenv = require('dotenv')

dotenv.config()

const app = express()

// Middleware
app.use(express.json())

// Routes
const workoutRoutes = require('./routes/workouts')
app.use('/api/workouts', workoutRoutes)

// MongoDB connectie
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log("Database verbonden & server draait")
    app.listen(process.env.PORT || 4000, () => {
      console.log(`Server draait op poort ${process.env.PORT || 4000}`)
    })
  })
  .catch((error) => {
    console.log(error)
  })
